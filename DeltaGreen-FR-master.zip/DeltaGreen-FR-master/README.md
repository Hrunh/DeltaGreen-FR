# DeltaGreen-FR
French translation for the DELTA GREEN game system on Foundry VTT
